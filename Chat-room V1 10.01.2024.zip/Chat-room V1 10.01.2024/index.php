<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
        <meta name="description" content="" />
        <meta name="author" content="" />
        <title>Misty Mountains</title>
        <link rel="icon" type="image/x-icon" href="assets/favicon.ico" />
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.3.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Varela+Round" rel="stylesheet" />
        <link href="https://fonts.googleapis.com/css?family=Nunito:200,200i,300,300i,400,400i,600,600i,700,700i,800,800i,900,900i" rel="stylesheet" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
            <div class="container px-4 px-lg-5">
                <a class="navbar-brand" href="#page-top">Misty Mountains -- Chat Room</a>
                <button class="navbar-toggler navbar-toggler-right" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item"><a class="nav-link" href="#page-top">About</a></li>
                        <li class="nav-item"><a class="nav-link" href="#projects">Chat Room</a></li>
                        <li class="nav-item"><a class="nav-link" href="#contact">Contact</a></li>
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
        <header class="masthead">
            <div class="container px-4 px-lg-5 d-flex h-100 align-items-center justify-content-center">
                <div class="d-flex justify-content-center">
                    <div class="text-center">
                        <h1 class="mx-auto my-0 text-uppercase">Misty Mountains</h1>
                        <h2 class="text-white-50 mx-auto mt-2 mb-5">A simple chat room, allowing you to share messages and media</h2>
                        <a class="btn btn-primary" href="#about">Get Started</a>
                    </div>
                </div>
            </div>
        </header>
        <!-- About-->
        
        <!-- Projects-->
        <section class="projects-section bg-light" id="projects">
            <!-- <div class="container px-4 px-lg-5"> -->
                <!-- Chat Room-->
                <!-- <h4>Chat Room</h4>
                    <div id="chat">
                        <div id="messages"></div>
                        <form id="message-form">
                            <input type="text" id="message-input" placeholder="Type your message...">
                            <button type="submit">Send</button>
                        </form>
                    </div>
                    <script src="app.js"></script>
            </div> -->

            <section class="page-section cta">
            <div class="container">
                <div class="row">
                    <div class="col-xl-9 mx-auto">
                        <div class="cta-inner bg-faded text-center rounded">
                            <h2 class="section-heading mb-5">
                                <span class="section-heading-upper"> </span>
                                <!-- <span class="section-heading-lower">Rate My Cake</span> -->
                            </h2>
    
                            <div style="display: inline-block; text-align: center;">
                                <form action="post.php" method="post" enctype="multipart/form-data">
                                <!-- <img id="blah" class="img-thumbnail rounded" style="background-color: #d2984f; max-width: 100%;" src="#" hidden> -->

                                  <textarea name="message" rows="2" cols="50" placeholder="Message..." required maxlength="255"></textarea>
                                  <br>
                                <input type="hidden" id="user_id" name="user_id" value="3">

                                  <input style="width:100%;" type="submit" value="Send Message" />
                                  <!-- <input type="hidden" id="width" name="width" value=" 0"> -->
                                        <!-- <input type="hidden" id="time" name="time" value=" 0">
                                        <input type="hidden" id="height" name="height" value=" 0">
                                      <input type="hidden" name="userid" placeholder="Enter your email..."><br>
                                        
                                    <input type="hidden" name="password" placeholder="Enter your password"><br> -->
                                <!-- This is the Image preview window -->

                                </form>
                            </div>
                            <?php  
                              if ((isset($_SESSION["error"])) && ($_SESSION["error"])){
                                echo $_SESSION["error"];
                                $_SESSION["error"] = "";

                              } 
                            ?>

                        </div>
                    </div>
                </div>
            </div>
        </section>
        
        <?php
         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "mistymountains";
     
         // Create connection
         $conn = new mysqli($servername, $username, $password, $dbName);
         if ($conn->connect_error) {;
                 die();
         }
         $stmt = $conn->prepare("SELECT * FROM messages");
         
        // ORDER BY review_id DESC

        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // output data of each row
            while ($row = $result->fetch_assoc()) {
                $imageId = $row["id"];
                $file = $row["message"];
                $message = $row["message"];

                $array = array("id", "message", "user_id");
            
            echo "<section class='page-section cta'>
                <div class='container'>
                    <div class='row'>
                        <div class='col-xl-9 mx-auto'>
                            <div class='cta-inner bg-faded text-center rounded'>
                                <div style='display: inline-block; text-align: center;'>
                                    <br>
                                    
                                    <h1>" . $message . "</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            ";
               
        }
    } else {
        $status = "loggedOut";
        $_SESSION['error'] = "Error: these details are incorrect. Please try again.";
        $_SESSION["status"] = $status;
        // header("location:index.php");
        $conn->close();
    }
        ?>
        </section>
        <!-- Signup-->
        
        <!-- Contact-->
        <section class="contact-section bg-black" id="contact">
            <div class="container px-4 px-lg-5">
                <div class="row gx-4 gx-lg-5">
                    <div class="col-md-4 mb-3 mb-md-0">
                        <div class="card py-4 h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-map-marked-alt text-primary mb-2"></i>
                                <h4 class="text-uppercase m-0">Address</h4>
                                <hr class="my-4 mx-auto" />
                                <div class="small text-black-50">Shipley College, Victoria Road, BD18 3LQ</div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 mb-md-0">
                        <div class="card py-4 h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-envelope text-primary mb-2"></i>
                                <h4 class="text-uppercase m-0">Email</h4>
                                <hr class="my-4 mx-auto" />
                                <div class="small text-black-50"><a href="#!">122752@shipley.ac.uk</a></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 mb-3 mb-md-0">
                        <div class="card py-4 h-100">
                            <div class="card-body text-center">
                                <i class="fas fa-mobile-alt text-primary mb-2"></i>
                                <h4 class="text-uppercase m-0">Phone</h4>
                                <hr class="my-4 mx-auto" />
                                <div class="small text-black-50">[Phone Number]</div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="social d-flex justify-content-center">
                    <a class="mx-2" href="https://twitter.com/NicholasBeard17"><i class="fab fa-twitter"></i></a>
                    <a class="mx-2" href="https://www.instagram.com/legion_of_justice20182023/"><i class="fab fa-instagram"></i></a>
                    <a class="mx-2" href="https://github.com/nicbeard1"><i class="fab fa-github"></i></a>
                </div>
            </div>
        </section>
        <!-- Footer-->
        <footer class="footer bg-black small text-center text-white-50"><div class="container px-4 px-lg-5">Copyright &copy; Misty Mountains 2024</div></footer>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
