/*!
* Start Bootstrap - Grayscale v7.0.6 (https://startbootstrap.com/theme/grayscale)
* Copyright 2013-2023 Start Bootstrap
* Licensed under MIT (https://github.com/StartBootstrap/startbootstrap-grayscale/blob/master/LICENSE)
*/
//
// Scripts
// 

const messages = document.getElementById('messages');
const messageForm = document.getElementById('message-form');
const messageInput = document.getElementById('message-input');

const socket = new WebSocket('ws://localhost:8080');

socket.addEventListener('message', event => {
    const message = document.createElement('div');
    message.textContent = event.data;
    messages.appendChild(message);
});

messageForm.addEventListener('submit', event => {
    event.preventDefault();
    socket.send(messageInput.value);
    messageInput.value = '';
});