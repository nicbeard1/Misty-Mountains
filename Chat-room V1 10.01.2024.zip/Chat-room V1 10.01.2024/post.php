    
<?php
     
// Save the message to a directory on the server
$message = $_POST["message"];
// $AIid = $_POST["id"]; 
$userid = $_POST["user_id"]; 

// Redirect the user to the main page
         $servername = "localhost";
         $username = "root";
         $password = "";
         $dbName = "mistymountains";
     
         // Create connection
         $conn = new mysqli($servername, $username, $password, $dbName);
         if ($conn->connect_error) {;
                 die();
         }
$stmt = $conn->prepare("INSERT INTO messages (message,user_id) VALUES (?,?)");
$stmt->bind_param("ss", $message, $userid);
$stmt->execute(); 

header('Location:index.php');
exit();

?>